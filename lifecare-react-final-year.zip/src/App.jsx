import React, { useEffect, useMemo, useState } from 'react'

const LAB = 'LifeCare Medical Laboratory'
const TESTS = {
  'Complete Blood Count (CBC)': [
    ['Hemoglobin','g/dL',[13,17],[12,15]], ['WBC Count','×10³/µL',[4,11]],
    ['RBC Count','million/µL',[4.5,5.9],[4.1,5.1]], ['Platelets','×10³/µL',[150,450]],
    ['Hematocrit','%',[40,52],[36,46]]
  ],
  'Lipid Profile': [['Total Cholesterol','mg/dL',[0,200]],['Triglycerides','mg/dL',[0,150]],['HDL Cholesterol','mg/dL',[40,100]],['LDL Cholesterol','mg/dL',[0,100]]],
  'Liver Function Test (LFT)': [['ALT (SGPT)','U/L',[7,56]],['AST (SGOT)','U/L',[10,40]],['Alkaline Phosphatase','U/L',[44,147]],['Total Bilirubin','mg/dL',[0.1,1.2]]],
  'Blood Sugar': [['Fasting Blood Sugar','mg/dL',[70,100]],['Random Blood Sugar','mg/dL',[70,140]],['HbA1c','%',[4,5.6]]],
  'Thyroid Profile': [['TSH','mIU/L',[0.4,4]],['T3','ng/dL',[80,200]],['T4','µg/dL',[5,12]]],
  'Kidney Function Test': [['Urea','mg/dL',[15,40]],['Creatinine','mg/dL',[0.6,1.3],[0.5,1.1]],['Uric Acid','mg/dL',[3.5,7.2],[2.6,6]]]
}
const DISEASES = {
  'Infectious': 'Tuberculosis,Malaria,Dengue Fever,Typhoid,Cholera,Hepatitis A,Hepatitis B,Hepatitis C,COVID-19,Influenza,Pneumonia,Measles,Chickenpox,Meningitis,Leishmaniasis,Chikungunya,Scabies,Ringworm,Syphilis,Gonorrhea,Chlamydia,Giardiasis,Amoebiasis,Sepsis',
  'Heart & Blood Vessels': 'Hypertension,Coronary Artery Disease,Heart Attack,Heart Failure,Arrhythmia,Stroke,Cardiomyopathy,Angina,Deep Vein Thrombosis,Varicose Veins',
  'Respiratory': 'Asthma,COPD,Bronchitis,Emphysema,Sleep Apnea,Sinusitis,Pulmonary Fibrosis,Tonsillitis,Allergic Rhinitis',
  'Digestive & Liver': 'GERD (Acidity),Peptic Ulcer,Gastritis,Irritable Bowel Syndrome,Crohn’s Disease,Ulcerative Colitis,Gallstones,Pancreatitis,Fatty Liver,Cirrhosis,Appendicitis,Constipation,Jaundice',
  'Hormonal & Metabolic': 'Type 1 Diabetes,Type 2 Diabetes,Gestational Diabetes,Hypothyroidism,Hyperthyroidism,PCOS,Obesity,Gout,Osteoporosis,High Cholesterol,Vitamin D Deficiency,Vitamin B12 Deficiency,Iron Deficiency',
  'Cancer': 'Breast Cancer,Lung Cancer,Colorectal Cancer,Prostate Cancer,Stomach Cancer,Liver Cancer,Cervical Cancer,Ovarian Cancer,Leukemia,Lymphoma,Brain Tumor',
  'Brain & Nerves': 'Epilepsy,Migraine,Alzheimer’s Disease,Parkinson’s Disease,Multiple Sclerosis,Peripheral Neuropathy,Dementia,Vertigo,Sciatica',
  'Mental Health': 'Depression,Anxiety Disorder,Bipolar Disorder,Schizophrenia,OCD,PTSD,ADHD,Panic Disorder,Insomnia,Phobias',
  'Blood Disorders': 'Anemia,Sickle Cell Disease,Thalassemia,Hemophilia,Polycythemia',
  'Kidney & Urinary': 'Chronic Kidney Disease,Kidney Stones,Urinary Tract Infection,Glomerulonephritis,Urinary Incontinence,Acute Kidney Injury',
  'Bones, Joints & Muscles': 'Osteoarthritis,Rheumatoid Arthritis,Fibromyalgia,Lupus,Scoliosis,Tendinitis,Fracture,Slipped Disc',
  'Skin & Hair': 'Eczema,Psoriasis,Acne,Vitiligo,Urticaria,Alopecia,Rosacea,Fungal Skin Infection',
  'Eye, Ear, Nose & Dental': 'Cataract,Glaucoma,Conjunctivitis,Macular Degeneration,Myopia,Ear Infection,Hearing Loss,Dental Cavities,Gingivitis',
  'Women & Children': 'Endometriosis,Uterine Fibroids,Infertility,Menopause,Neonatal Jaundice,Down Syndrome,Cleft Lip',
  'Immune & Allergy': 'Allergies,Anaphylaxis,Hashimoto’s Thyroiditis,Graves’ Disease,Sarcoidosis,Vasculitis',
  'Genetic & Rare': 'Marfan Syndrome,Turner Syndrome,Klinefelter Syndrome,Tay-Sachs Disease,Gaucher Disease',
  'Environmental & Injury': 'Heatstroke,Hypothermia,Snake Bite,Lead Poisoning,Burns,Silicosis'
}
const allDiseases = Object.entries(DISEASES).flatMap(([category, names]) => names.split(',').map(name => ({name, category})))
const read = key => { try { return JSON.parse(localStorage.getItem(`lc_${key}`) || '[]') } catch { return [] } }
const write = (key, value) => localStorage.setItem(`lc_${key}`, JSON.stringify(value))
const makeId = prefix => `${prefix}${Date.now().toString(36).toUpperCase()}`
const getRange = (test, gender) => gender === 'Female' && test[3] ? test[3] : test[2]
const rangeText = r => `${r[0]} – ${r[1]}`
const flag = (v, r) => Number(v) < r[0] ? 'LOW' : Number(v) > r[1] ? 'HIGH' : 'NORMAL'
const safeDate = v => v ? new Date(v).toLocaleDateString() : '—'

function Field({label, children}) { return <label className="field"><span>{label}</span>{children}</label> }
function Header({subtitle, right}) { return <header className="topbar"><div><h1>🩺 {LAB}</h1><small>{subtitle}</small></div>{right}</header> }
function DiseaseGuide() {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('')
  const results = useMemo(() => allDiseases.filter(d => (!category || d.category === category) && d.name.toLowerCase().includes(query.toLowerCase().trim())), [query, category])
  const grouped = useMemo(() => results.reduce((acc, d) => ((acc[d.category] ||= []).push(d.name), acc), {}), [results])
  return <section className="card">
    <h2>Disease Guide <span className="muted">({allDiseases.length}+ conditions)</span></h2>
    <p className="muted">General reference only. This guide does not diagnose conditions or replace medical advice.</p>
    <div className="grid two"><Field label="Search diseases"><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="e.g. diabetes, asthma, dengue" /></Field>
      <Field label="Category"><select value={category} onChange={e=>setCategory(e.target.value)}><option value="">All categories</option>{Object.keys(DISEASES).map(c=><option key={c}>{c}</option>)}</select></Field></div>
    {Object.entries(grouped).map(([c,names])=><div className="disease-group" key={c}><h3>{c} <small>({names.length})</small></h3><div className="tags">{names.map(n=><span className="tag" key={n}>{n}</span>)}</div></div>)}
    {!results.length && <p>No matching diseases found.</p>}
  </section>
}
function BookingForm({onBooked}) {
  const [form, setForm] = useState({name:'',phone:'',age:'',gender:'Male',test:Object.keys(TESTS)[0],date:'',slot:'Morning 7–10',type:'Home sample collection',address:'',doctor:''})
  const [error, setError] = useState('')
  const [booking, setBooking] = useState(null)
  const update = e => setForm({...form, [e.target.name]:e.target.value})
  function submit(e) {
    e.preventDefault(); setError('')
    if (!form.name.trim() || form.phone.replace(/\D/g,'').length < 7 || form.age === '' || Number(form.age)<0 || Number(form.age)>120 || !form.date) return setError('Enter patient name, a valid phone number, age and preferred date.')
    if (form.type.startsWith('Home') && !form.address.trim()) return setError('Please enter the address for home sample collection.')
    const record = {...form, age:Number(form.age), doctor:form.doctor.trim() || 'Self', id:makeId('BK'), status:'Pending', created:Date.now()}
    const list = read('bookings'); list.push(record); write('bookings', list)
    setBooking(record); onBooked?.()
  }
  if (booking) return <section className="card success"><h2>✅ Booking received</h2><p>Your booking ID is <b>{booking.id}</b>. Our team will call <b>{booking.phone}</b> to confirm {booking.test} on {booking.date} ({booking.slot}).</p><button onClick={()=>{setBooking(null);setForm({...form,name:'',phone:'',age:'',date:'',address:'',doctor:''})}}>Book another test</button></section>
  return <section className="card"><h2>Book a Lab Test</h2><p className="muted">Fill in your details. Our team will contact you to confirm the booking.</p>
    <form onSubmit={submit}><div className="grid two">
      <Field label="Patient name"><input name="name" value={form.name} onChange={update} required /></Field>
      <Field label="Phone number"><input name="phone" type="tel" value={form.phone} onChange={update} required /></Field>
      <Field label="Age (years)"><input name="age" type="number" min="0" max="120" value={form.age} onChange={update} required /></Field>
      <Field label="Gender"><select name="gender" value={form.gender} onChange={update}><option>Male</option><option>Female</option><option>Other</option></select></Field>
      <Field label="Test"><select name="test" value={form.test} onChange={update}>{Object.keys(TESTS).map(t=><option key={t}>{t}</option>)}</select></Field>
      <Field label="Preferred date"><input name="date" type="date" min={new Date().toISOString().slice(0,10)} value={form.date} onChange={update} required /></Field>
      <Field label="Time slot"><select name="slot" value={form.slot} onChange={update}>{['Morning 7–10','Late morning 10–1','Afternoon 1–4','Evening 4–7'].map(x=><option key={x}>{x}</option>)}</select></Field>
      <Field label="Sample collection"><select name="type" value={form.type} onChange={update}><option>Home sample collection</option><option>Visit the lab</option></select></Field>
      <Field label="Address (for home collection)"><input name="address" value={form.address} onChange={update} /></Field>
      <Field label="Doctor (optional)"><input name="doctor" value={form.doctor} onChange={update} /></Field>
    </div>{error && <p className="error">{error}</p>}<button type="submit">Book Test</button></form>
  </section>
}
function Login({staff, onLogin, onSetup, onPublic}) {
  const first = staff.length === 0
  const [name,setName] = useState(''); const [username,setUsername] = useState(''); const [password,setPassword] = useState(''); const [error,setError] = useState('')
  async function submit(e) { e.preventDefault(); setError(''); const result = first ? await onSetup(name,username,password) : await onLogin(username,password); if (result) setError(result) }
  return <main className="narrow"><section className="card"><h2>🩺 {LAB}</h2><p>{first?'First-time setup: create an administrator account.':'Authorised staff only. Please sign in.'}</p>
    <form onSubmit={submit}>{first && <Field label="Full name"><input value={name} onChange={e=>setName(e.target.value)} required /></Field>}
      <Field label="Username"><input value={username} onChange={e=>setUsername(e.target.value)} autoComplete="username" required /></Field>
      <Field label="Password (minimum 6 characters)"><input type="password" value={password} onChange={e=>setPassword(e.target.value)} autoComplete="current-password" required /></Field>
      {error && <p className="error">{error}</p>}<button>{first?'Create Admin':'Sign In'}</button> <button type="button" className="secondary" onClick={onPublic}>Public Page</button>
    </form></section></main>
}
function PatientForm({editing, onSave, onCancel}) {
  const [form,setForm] = useState({name:editing?.name||'',age:editing?.age??'',gender:editing?.gender||'Male',test:editing?.test||Object.keys(TESTS)[0],doctor:editing?.doctor||''})
  const [error,setError] = useState('')
  const update = e => setForm({...form,[e.target.name]:e.target.value})
  function submit(e) { e.preventDefault(); if(!form.name.trim() || form.age==='' || Number(form.age)<0 || !form.doctor.trim()) return setError('Please fill in all fields.'); onSave({...form,age:Number(form.age)}) }
  return <section className="card"><h2>{editing?`Edit patient ${editing.id}`:'New Patient Entry'}</h2><form onSubmit={submit}><div className="grid two">
    <Field label="Patient name"><input name="name" value={form.name} onChange={update} required /></Field>
    <Field label="Age (years)"><input name="age" type="number" min="0" max="120" value={form.age} onChange={update} required /></Field>
    <Field label="Gender"><select name="gender" value={form.gender} onChange={update}><option>Male</option><option>Female</option><option>Other</option></select></Field>
    <Field label="Test type"><select name="test" value={form.test} onChange={update}>{Object.keys(TESTS).map(t=><option key={t}>{t}</option>)}</select></Field>
    <Field label="Referred by (doctor)"><input name="doctor" value={form.doctor} onChange={update} required /></Field>
  </div>{error && <p className="error">{error}</p>}<button>{editing?'Update Patient':'Register Patient'}</button> {editing && <button type="button" className="secondary" onClick={onCancel}>Cancel</button>}</form></section>
}
function ResultsModal({patient,onClose,onSave}) {
  const [values,setValues] = useState(patient.results||{})
  const [error,setError] = useState('')
  const tests = TESTS[patient.test]||[]
  function submit(done) {
    if(done && tests.some(t=>values[t[0]]==null || values[t[0]]==='')) return setError('Enter every result before completing.')
    onSave(patient.id, values, done)
  }
  return <div className="overlay"><section className="card modal"><button className="close secondary" onClick={onClose}>Close ✕</button><h2>{patient.test}</h2><p>{patient.name} · {patient.age} years · {patient.gender} · ID {patient.id}</p>
    <div className="table-wrap"><table><thead><tr><th>Parameter</th><th>Result</th><th>Unit</th><th>Normal range</th></tr></thead><tbody>{tests.map((t,i)=><tr key={t[0]}><td>{t[0]}</td><td><input type="number" step="any" value={values[t[0]]??''} onChange={e=>setValues({...values,[t[0]]:e.target.value})}/></td><td>{t[1]}</td><td>{rangeText(getRange(t,patient.gender))}</td></tr>)}</tbody></table></div>
    {error && <p className="error">{error}</p>}<button onClick={()=>submit(true)}>Complete Test</button> <button className="secondary" onClick={()=>submit(false)}>Save Draft</button>
  </section></div>
}
function ReportModal({patient,onClose}) {
  const tests = TESTS[patient.test]||[]
  return <div className="overlay report-overlay"><div className="report-actions"><button onClick={()=>window.print()}>🖨 Print / Save PDF</button> <button className="secondary" onClick={onClose}>Close</button></div><section className="report" id="print-report">
    <div className="report-head"><h2>{LAB}</h2><p>Diagnostic &amp; Pathology Services</p></div><h3 className="center">LABORATORY REPORT</h3>
    <div className="patient-details"><div><b>Patient:</b> {patient.name}</div><div><b>Report ID:</b> {patient.id}</div><div><b>Age / Gender:</b> {patient.age} years / {patient.gender}</div><div><b>Referred by:</b> Dr. {patient.doctor.replace(/^dr\.?\s*/i,'')}</div><div><b>Registered:</b> {safeDate(patient.created)}</div><div><b>Reported:</b> {safeDate(patient.completed||Date.now())}</div></div>
    <h3>{patient.test}</h3><table><thead><tr><th>Test</th><th>Result</th><th>Unit</th><th>Normal range</th><th>Status</th></tr></thead><tbody>{tests.map(t=>{const r=getRange(t,patient.gender),v=patient.results?.[t[0]];return <tr key={t[0]}><td>{t[0]}</td><td><b>{v??'—'}</b></td><td>{t[1]}</td><td>{rangeText(r)}</td><td className={v==null?'':flag(v,r)}>{v==null?'—':flag(v,r)}</td></tr>})}</tbody></table>
    <div className="signature"><span>Technician: {patient.completedBy||'—'}</span><span>Pathologist signature</span></div><p className="fineprint">Computer-generated report. Please correlate clinically; consult your physician for interpretation.</p>
  </section></div>
}
function StaffManager({staff,user,onAdd,onDelete}) {
  const [form,setForm] = useState({name:'',username:'',password:'',role:'technician'}); const [error,setError] = useState('')
  function submit(e) { e.preventDefault(); const result=onAdd(form); if(result) setError(result); else setForm({name:'',username:'',password:'',role:'technician'}) }
  return <><section className="card"><h2>Add Staff Member</h2><form onSubmit={submit}><div className="grid two">
    <Field label="Full name"><input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required /></Field>
    <Field label="Username"><input value={form.username} onChange={e=>setForm({...form,username:e.target.value})} required /></Field>
    <Field label="Password (minimum 6 characters)"><input type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} required /></Field>
    <Field label="Role"><select value={form.role} onChange={e=>setForm({...form,role:e.target.value})}><option value="technician">Technician</option><option value="admin">Admin</option></select></Field>
  </div>{error && <p className="error">{error}</p>}<button>Add Staff</button></form></section>
  <section className="card table-wrap"><h2>Staff Accounts</h2><table><thead><tr><th>Name</th><th>Username</th><th>Role</th><th>Action</th></tr></thead><tbody>{staff.map(s=><tr key={s.id}><td>{s.name}</td><td>{s.id}</td><td>{s.role}</td><td>{s.id===user.id?'(you)':<button className="danger small" onClick={()=>onDelete(s.id)}>Remove</button>}</td></tr>)}</tbody></table></section></>
}
export default function App() {
  const [patients,setPatients] = useState(()=>read('patients'))
  const [bookings,setBookings] = useState(()=>read('bookings'))
  const [staff,setStaff] = useState(()=>read('staff'))
  const [user,setUser] = useState(null)
  const [page,setPage] = useState('book')
  const [tab,setTab] = useState('register')
  const [query,setQuery] = useState('')
  const [editing,setEditing] = useState(null)
  const [resultPatient,setResultPatient] = useState(null)
  const [reportPatient,setReportPatient] = useState(null)
  const [notice,setNotice] = useState('')
  useEffect(()=>{write('patients',patients)},[patients])
  useEffect(()=>{write('bookings',bookings)},[bookings])
  useEffect(()=>{write('staff',staff)},[staff])
  useEffect(()=>{const id=sessionStorage.getItem('lc_u');if(id){const found=read('staff').find(s=>s.id===id);if(found)setUser(found)}},[])
  function setup(name,username,password) {
    const n=name.trim(),u=username.trim().toLowerCase()
    if(!n || !/^[a-z0-9_.-]+$/.test(u) || password.length<6) return Promise.resolve('Enter a name, valid username and password of 6+ characters.')
    if(staff.some(s=>s.id===u)) return Promise.resolve('Username already exists.')
    const rec={id:u,name:n,role:'admin',password};setStaff([...staff,rec]);setUser(rec);sessionStorage.setItem('lc_u',u);setPage('staff');return Promise.resolve('')
  }
  function login(username,password) {
    const u=username.trim().toLowerCase(),found=staff.find(s=>s.id===u && s.password===password)
    if(!found)return Promise.resolve('Invalid username or password.')
    setUser(found);sessionStorage.setItem('lc_u',u);setPage('staff');return Promise.resolve('')
  }
  function logout(){setUser(null);sessionStorage.removeItem('lc_u');setPage('book');setNotice('')}
  function savePatient(data) {
    if(editing) setPatients(prev=>prev.map(p=>p.id===editing.id?{...p,...data,...(p.test!==data.test?{results:null,status:'Pending'}:{})}:p))
    else setPatients(prev=>[{...data,id:makeId('LC'),status:'Pending',results:null,created:Date.now(),by:user.name},...prev])
    setEditing(null);setTab('records');setNotice('Patient record saved successfully.')
  }
  function saveResults(id,results,done) {
    setPatients(prev=>prev.map(p=>p.id===id?{...p,results:Object.fromEntries(Object.entries(results).map(([k,v])=>[k,v===''?v:Number(v)])),...(done?{status:'Completed',completed:Date.now(),completedBy:user.name}:{})}:p))
    setResultPatient(null);if(done){const p=patients.find(p=>p.id===id);if(p)setReportPatient({...p,results:Object.fromEntries(Object.entries(results).map(([k,v])=>[k,v===''?v:Number(v)])),status:'Completed',completed:Date.now(),completedBy:user.name})}
  }
  function addStaff(data) {
    const u=data.username.trim().toLowerCase()
    if(!data.name.trim() || !/^[a-z0-9_.-]+$/.test(u) || data.password.length<6)return 'Name, valid username and 6+ character password required.'
    if(staff.some(s=>s.id===u))return 'Username already exists.'
    setStaff([...staff,{id:u,name:data.name.trim(),role:data.role,password:data.password}]);return ''
  }
  function deletePatient(id){if(window.confirm(`Delete patient record ${id}?`))setPatients(p=>p.filter(x=>x.id!==id))}
  function registerBooking(b) {setBookings(prev=>[b,...prev])}
  function confirmBooking(id,status){setBookings(prev=>prev.map(b=>b.id===id?{...b,status}:b))}
  function registerFromBooking(b){setPatients(prev=>[{...b,id:makeId('LC'),status:'Pending',results:null,created:Date.now(),by:user.name},...prev]);confirmBooking(b.id,'Registered');setTab('records')}
  const filteredPatients=patients.filter(p=>[p.id,p.name,p.test,p.doctor].join(' ').toLowerCase().includes(query.toLowerCase())).sort((a,b)=>b.created-a.created)
  const pending=bookings.filter(b=>b.status==='Pending').length
  if(!user && page==='login')return <><Header subtitle="Staff portal" right={<button className="secondary light" onClick={()=>setPage('book')}>Public page</button>}/><Login staff={staff} onSetup={setup} onLogin={login} onPublic={()=>setPage('book')}/></>
  if(!user && page==='guide')return <><Header subtitle="Public disease guide" right={<button className="secondary light" onClick={()=>setPage('login')}>Staff sign in</button>}/><main><DiseaseGuide/></main></>
  if(!user)return <><Header subtitle="Book lab tests from home" right={<button className="secondary light" onClick={()=>setPage('login')}>Staff sign in</button>}/><main><nav className="tabs"><button className={page==='book'?'active':''} onClick={()=>setPage('book')}>Book a Test</button><button className={page==='guide'?'active':''} onClick={()=>setPage('guide')}>Disease Guide</button></nav>{page==='book'?<BookingForm onBooked={()=>{setBookings(read('bookings'))}}/>:<DiseaseGuide/></main><footer>© {new Date().getFullYear()} {LAB} · Educational project demo</footer></>
  return <>
    <Header subtitle={`${user.name} (${user.role}) · Browser-local demo storage`} right={<button className="secondary light" onClick={logout}>Log out</button>}/>
    <main><nav className="tabs">
      <button className={tab==='register'?'active':''} onClick={()=>{setTab('register');setEditing(null)}}>Register Patient</button>
      <button className={tab==='records'?'active':''} onClick={()=>setTab('records')}>Records ({patients.length})</button>
      <button className={tab==='bookings'?'active':''} onClick={()=>setTab('bookings')}>Bookings ({pending} pending)</button>
      <button className={tab==='diseases'?'active':''} onClick={()=>setTab('diseases')}>Disease Guide</button>
      {user.role==='admin' && <button className={tab==='staff'?'active':''} onClick={()=>setTab('staff')}>Staff</button>}
    </nav>
    {notice && <div className="notice">{notice}<button className="text-button" onClick={()=>setNotice('')}>Dismiss</button></div>}
    {tab==='register' && <PatientForm key={editing?.id||'new'} editing={editing} onSave={savePatient} onCancel={()=>{setEditing(null);setTab('records')}}/>}
    {tab==='records' && <section className="card"><h2>Patient Records</h2><input className="search" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search by patient, ID, test or doctor"/><div className="table-wrap"><table><thead><tr><th>ID</th><th>Patient</th><th>Age/Sex</th><th>Test</th><th>Doctor</th><th>Date</th><th>Status</th><th>Actions</th></tr></thead><tbody>{filteredPatients.map(p=><tr key={p.id}><td>{p.id}</td><td>{p.name}</td><td>{p.age}/{p.gender?.[0]}</td><td>{p.test}</td><td>{p.doctor}</td><td>{safeDate(p.created)}</td><td><span className={`status ${p.status}`}>{p.status}</span></td><td className="actions"><button className="small" onClick={()=>setResultPatient(p)}>{p.status==='Completed'?'Edit Results':'Enter Results'}</button>{p.status==='Completed'&&<button className="secondary small" onClick={()=>setReportPatient(p)}>Report</button>}<button className="secondary small" onClick={()=>{setEditing(p);setTab('register')}}>Edit</button>{user.role==='admin'&&<button className="danger small" onClick={()=>deletePatient(p.id)}>Delete</button>}</td></tr>)}</tbody></table>{!filteredPatients.length&&<p>No patient records found.</p>}</div></section>}
    {tab==='bookings' && <section className="card"><h2>Test Bookings</h2><div className="table-wrap"><table><thead><tr><th>ID</th><th>Patient</th><th>Phone</th><th>Test</th><th>Date & Time</th><th>Collection</th><th>Status</th><th>Actions</th></tr></thead><tbody>{bookings.slice().sort((a,b)=>b.created-a.created).map(b=><tr key={b.id}><td>{b.id}</td><td>{b.name}<br/><small>{b.age}/{b.gender?.[0]}</small></td><td>{b.phone}</td><td>{b.test}</td><td>{b.date}<br/><small>{b.slot}</small></td><td>{b.type}{b.address&&<><br/><small>{b.address}</small></>}</td><td><span className={`status ${b.status}`}>{b.status}</span></td><td className="actions">{b.status==='Pending'&&<button className="small" onClick={()=>confirmBooking(b.id,'Confirmed')}>Confirm</button>}{b.status!=='Registered'&&<button className="secondary small" onClick={()=>registerFromBooking(b)}>Register Patient</button>}<button className="danger small" onClick={()=>{if(window.confirm('Delete this booking?'))setBookings(prev=>prev.filter(x=>x.id!==b.id))}}>Delete</button></td></tr>)}</tbody></table>{!bookings.length&&<p>No bookings yet.</p>}</div></section>}
    {tab==='diseases' && <DiseaseGuide/>}
    {tab==='staff' && user.role==='admin' && <StaffManager staff={staff} user={user} onAdd={addStaff} onDelete={id=>{if(window.confirm(`Remove ${id}?`)){setStaff(prev=>prev.filter(s=>s.id!==id));if(user.id===id)logout()}}}/>}
    <footer>© {new Date().getFullYear()} {LAB} · Final Year Project prototype</footer></main>
    {resultPatient&&<ResultsModal patient={resultPatient} onClose={()=>setResultPatient(null)} onSave={saveResults}/>}
    {reportPatient&&<ReportModal patient={reportPatient} onClose={()=>setReportPatient(null)}/>}
  </>
}
